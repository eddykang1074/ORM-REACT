import React from "react";

const Index = () => {
  document.title = "샘플 페이지";

  return (
    <div>
      <h1>페이지 샘플</h1>
    </div>
  );
};

export default Index;
